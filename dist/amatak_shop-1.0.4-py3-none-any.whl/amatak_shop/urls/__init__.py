"""
Amatak Online Shop
Copyright© Amatak Holdings Pty Ltd licensed under the MIT Agreement.
If you interesting to be part of this project pleaese contact:
Rony MAN <amatak.io@outlook.com>
for business <www.amatak.io>
OpenSource <www.amatak.org>
"""
from amatak_shop.urls.add_coupon import *
from amatak_shop.urls.add_to_cart import *
from amatak_shop.urls.checkout import *
from amatak_shop.urls.home import *
from amatak_shop.urls.order_summary import *
from amatak_shop.urls.payment import *
from amatak_shop.urls.policy import *
from amatak_shop.urls.products import *
from amatak_shop.urls.remove_from_cart import *
from amatak_shop.urls.remove_single_item_from_cart import *
from amatak_shop.urls.request_refund import *
from amatak_shop.urls.terms import *

