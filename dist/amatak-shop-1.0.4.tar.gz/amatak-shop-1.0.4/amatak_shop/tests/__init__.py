"""
Amatak Online Shop
Copyright© Amatak Holdings Pty Ltd licensed under the MIT Agreement.
If you interesting to be part of this project pleaese contact:
Rony MAN <amatak.io@outlook.com>
for business <www.amatak.io>
OpenSource <www.amatak.org>
"""
from amatak_shop.urls.tests import *
default_app_config = 'amatak_shop.apps.AmatakShopConfig'

"""ACCOUNT AMATAK"""
__version__ = '1.0.1'
__license__ = 'MIT License'

__author__ = 'Amatak.io'
__email__ = 'amatak.io@outlook.com'

__url__ = 'https://www.amatak.io'