"""
AutoStore( Automotive Online Shop).
We launch this business Store live at www.autocare7.com
Copyright© Amatak Holdings Pty Ltd licensed under the MIT Agreement.
If you interesting to be part of this project pleaese contact:
Rony MAN <amatak.io@outlook.com>
for business <www.amatak.io>
OpenSource <www.amatak.org>
"""
from amatak_shop.views.add_coupon import *
from amatak_shop.views.add_to_cart import *
from amatak_shop.views.checkout import *
from amatak_shop.views.create_ref_code import *
from amatak_shop.views.get_coupon import *
from amatak_shop.views.home import *
from amatak_shop.views.is_valid_form import *
from amatak_shop.views.order_summary import *
from amatak_shop.views.payment import *
from amatak_shop.views.policy import *
from amatak_shop.views.products import *
from amatak_shop.views.remove_from_cart import *
from amatak_shop.views.remove_single_item_from_cart import *
from amatak_shop.views.request_refund import *
from amatak_shop.views.terms import *
from amatak_shop.views.items_detail_views import *


