__Amatak Online Shop__ was created and is currently maintained and developed by Amatak the full documetation an be found in
[amatak.org](https://amatak.org/docs/projects/AmatakOnlineShop)

### Join our  [Stack Overflow](https://stackoverflow.com/users/22269946/amatak)

To clone this project from 
[GitHub](https://github.com/amatak-org/AmatakOnlineShop).

### Here is briefly descript about this online shopping.


__This project can greatly benefit from contributions towards Documentation and Unit Tests.__
__This is the best way to get started twith this project if you are not familiar with the models.__

### Current Contents.
# Current Version 1.0.1

Style & Layout:

- Bootrap
- Bulma Css
- 
Store:
- Homepage
- Categories
- Navbar
- Footer
- Sidebar
Payment Choices
- Stripe
- Paypal
- payment refund
- Coupon Applied
Product Items:
- upload from admin

### Roadmap to version 1.0.2.

Style & Layout:

- Tiles Grid at the homepage
- pai
- Customize login/signUp
Store:
- Homepage
- Categories
Product Items:
- upload from admin
- Upload differnet images to one direction


# Homepage Screen
![Home Screen](static_in_env/img/screenshot.png)

# Client Coupon Views
![Check Out cart](static_in_env/img/screenshot_checkout_with_coupon.png)

# Client Checkout Views
![Check Out cart](static_in_env/img/screenshot_checkout.png)